
package impl;

import java.util.ArrayList;

public class ItensComida {
    
    public ItensComida(){
        itens = new ArrayList<String>();
    }
    
    public ArrayList<String> itens;
    
}
